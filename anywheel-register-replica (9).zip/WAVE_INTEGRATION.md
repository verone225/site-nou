# Intégration Wave réelle — étape conditionnelle

L’application conserve actuellement des demandes de dépôt et de retrait en attente de validation administrative. Aucune connexion à l’API Wave réelle n’est activée.

Une activation future nécessitera des identifiants Wave autorisés fournis par le propriétaire du compte marchand, la confirmation des permissions de paiement et de décaissement, la configuration des URLs de rappel sécurisées, ainsi qu’une validation réglementaire adaptée au marché ivoirien. Les secrets devront être ajoutés exclusivement via la gestion sécurisée des secrets du projet, puis couverts par des tests avant toute mise en production.

La logique actuelle peut donc être remplacée par un adaptateur Wave officiel après validation de ces prérequis, sans modifier les règles métier existantes : numéro ivoirien +225, suivi des statuts, journal comptable et contrôle administrateur.
