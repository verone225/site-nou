/*
 * Style reminder: la page unique reste centrée comme une capture mobile,
 * avec le formulaire Magnesium comme point focal et une sortie de navigation claire.
 */
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import HistoryPage from "./pages/HistoryPage";
import MyProductsPage from "./pages/MyProductsPage";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/reg" component={Home} />
      <Route path="/history" component={() => <HistoryPage />} />
      <Route path="/withdrawal-history" component={() => <HistoryPage withdrawalsOnly />} />
      <Route path="/my-products" component={MyProductsPage} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
