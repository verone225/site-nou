export const ADMIN_REFETCH_INTERVAL_MS = 3000;
export function shouldRefreshAfterAdminMutation() { return true; }
