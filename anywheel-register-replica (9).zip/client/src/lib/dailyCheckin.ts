export const DAILY_CHECKIN_BONUS = 50;

export function todayKey(date = new Date()) {
  return date.toISOString().slice(0, 10);
}

export function claimDailyCheckin(storage: Storage, date = new Date()) {
  const key = todayKey(date);
  if (storage.getItem("magnesium-last-checkin") === key) {
    return { claimed: false, bonusTotal: Number(storage.getItem("magnesium-daily-bonus") || "0") };
  }
  const bonusTotal = Number(storage.getItem("magnesium-daily-bonus") || "0") + DAILY_CHECKIN_BONUS;
  storage.setItem("magnesium-last-checkin", key);
  storage.setItem("magnesium-daily-bonus", String(bonusTotal));
  return { claimed: true, bonusTotal };
}
