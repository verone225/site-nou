export type TransactionStatus = "pending" | "approved" | "rejected";
export type DemoTransaction = { id: string; type: "deposit" | "withdrawal"; phone: string; amount: number; createdAt: string; status: TransactionStatus };
const STORAGE_KEY = "magnesium-demo-transactions";

export function getDemoTransactions(): DemoTransaction[] {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]") as DemoTransaction[]; } catch { return []; }
}

export function addDemoTransaction(input: Omit<DemoTransaction, "id" | "createdAt" | "status">) {
  const item: DemoTransaction = { ...input, id: crypto.randomUUID(), createdAt: new Date().toISOString(), status: "pending" };
  const next = [item, ...getDemoTransactions()];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  return item;
}

export function updateDemoTransactionStatus(id: string, status: TransactionStatus) {
  const next = getDemoTransactions().map(item => item.id === id ? { ...item, status } : item);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  return next;
}

export function maskWavePhone(phone: string) {
  const compact = phone.replace(/\s/g, "");
  return compact.length > 6 ? `${compact.slice(0, 7)}****${compact.slice(-2)}` : "****";
}
