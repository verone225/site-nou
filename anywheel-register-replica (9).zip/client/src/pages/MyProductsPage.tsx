import React from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";

const productPlans = [
  { match: "VIP1", daily: 750, total: 135000 },
  { match: "VIP2", daily: 1250, total: 225000 },
  { match: "VIP3", daily: 2550, total: 459000 },
  { match: "VIP4", daily: 6500, total: 1170000 },
];

function getPlan(productName: string) {
  return productPlans.find(plan => productName.startsWith(plan.match)) ?? { daily: 0, total: 0 };
}

function formatCfa(value: number) {
  return `${value.toLocaleString("fr-FR")} FCFA`;
}

function earnedDays(createdAt: Date) {
  const elapsed = Math.floor((Date.now() - new Date(createdAt).getTime()) / 86400000);
  return Math.max(0, Math.min(180, elapsed));
}

export default function MyProductsPage() {
  const [, setLocation] = useLocation();
  const { loading } = useAuth();
  const accountLabel = localStorage.getItem("magnesium-demo-account") || "";
  const isAccount = accountLabel.startsWith("225");
  const purchasesQuery = trpc.demoAccount.purchases.useQuery({ phone: `+${accountLabel}` }, { enabled: isAccount });

  if (loading || !isAccount) return <main className="history-page"><section className="history-page-card"><p className="eyebrow">Espace personnel</p><h1>Mes produits</h1><p className="history-page-empty">Connectez-vous pour consulter vos produits.</p><button className="auth-button" onClick={() => setLocation("/")}>Retour à la connexion</button></section></main>;

  return <main className="history-page"><section className="history-page-card"><header className="history-page-header"><div><p className="eyebrow">Compte personnel</p><h1>Mes produits</h1><p>Compte : +{accountLabel}</p></div><button className="history-back-button" onClick={() => setLocation("/")}>Retour au compte</button></header>{purchasesQuery.isLoading ? <p className="history-page-empty">Chargement de vos produits…</p> : purchasesQuery.isError ? <div className="history-page-empty" role="alert"><strong>Impossible de charger vos produits.</strong><p>Vérifiez votre connexion puis réessayez.</p><button className="auth-button" onClick={() => void purchasesQuery.refetch()}>Réessayer</button></div> : purchasesQuery.data?.length ? <div className="products-purchased-list">{purchasesQuery.data.map(product => { const plan = getPlan(product.productName); const days = earnedDays(product.createdAt); const accrued = Math.min(plan.total, days * plan.daily); const progress = plan.total ? Math.min(100, (accrued / plan.total) * 100) : 0; return <article className="purchased-product-card purchased-product-detail" key={product.id}><div className="purchased-product-top"><div><p className="purchased-product-status">{product.status === "completed" ? "Achat confirmé" : "Achat annulé"}</p><h2>{product.productName}</h2><p>Acheté le {new Date(product.createdAt).toLocaleString("fr-FR")}</p></div><strong>{formatCfa(product.amount)}</strong></div><div className="purchased-product-grid"><div><span>Durée du produit</span><b>180 jours</b></div><div><span>Revenu quotidien</span><b>{formatCfa(plan.daily)}</b></div><div><span>Jours écoulés</span><b>{days} / 180</b></div><div><span>Revenus cumulés</span><b>{formatCfa(accrued)}</b></div></div><div className="product-income-progress"><div><span>Évolution des revenus</span><b>{Math.round(progress)} %</b></div><div className="product-income-track"><span style={{ width: `${progress}%` }} /></div><small>Projection cumulée selon le nombre de jours écoulés depuis l’achat.</small></div></article>; })}</div> : <div className="history-page-empty"><strong>Aucun produit acheté</strong><p>Accédez à la rubrique Produit pour choisir un produit avec le solde de votre compte.</p><button className="auth-button" onClick={() => setLocation("/")}>Voir les produits</button></div>}</section></main>;
}
