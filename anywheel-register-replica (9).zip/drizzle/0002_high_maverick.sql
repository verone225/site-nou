CREATE TABLE `demo_ledger` (
	`id` int AUTO_INCREMENT NOT NULL,
	`accountPhone` varchar(20) NOT NULL,
	`kind` enum('deposit','revenue','referral','checkin','withdrawal') NOT NULL,
	`direction` enum('credit','debit') NOT NULL,
	`amount` int NOT NULL,
	`transactionId` int,
	`detail` varchar(255) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `demo_ledger_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `demo_transactions` ADD `accountPhone` varchar(20) NULL;
--> statement-breakpoint
UPDATE `demo_transactions` SET `accountPhone` = `phone` WHERE `accountPhone` IS NULL;
--> statement-breakpoint
ALTER TABLE `demo_transactions` MODIFY `accountPhone` varchar(20) NOT NULL;