CREATE TABLE `demo_purchases` (
	`id` int AUTO_INCREMENT NOT NULL,
	`accountPhone` varchar(20) NOT NULL,
	`productName` varchar(100) NOT NULL,
	`amount` int NOT NULL,
	`status` enum('completed','cancelled') NOT NULL DEFAULT 'completed',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `demo_purchases_id` PRIMARY KEY(`id`)
);
