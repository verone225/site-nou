ALTER TABLE `demo_accounts` MODIFY COLUMN `balanceCfa` int NOT NULL DEFAULT 1000;--> statement-breakpoint
ALTER TABLE `demo_accounts` MODIFY COLUMN `cumulativeRevenueCfa` int NOT NULL DEFAULT 1000;
