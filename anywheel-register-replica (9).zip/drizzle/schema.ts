import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const demoAccounts = mysqlTable("demo_accounts", {
  id: int("id").autoincrement().primaryKey(),
  phone: varchar("phone", { length: 20 }).notNull().unique(),
  codeHash: varchar("codeHash", { length: 128 }).notNull(),
  inviteCode: varchar("inviteCode", { length: 32 }).notNull(),
  referrerPhone: varchar("referrerPhone", { length: 20 }),
  balanceCfa: int("balanceCfa").default(1500).notNull(),
  cumulativeRevenueCfa: int("cumulativeRevenueCfa").default(1500).notNull(),
  referralRevenueCfa: int("referralRevenueCfa").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DemoAccount = typeof demoAccounts.$inferSelect;
export type InsertDemoAccount = typeof demoAccounts.$inferInsert;

export const demoTransactions = mysqlTable("demo_transactions", {
  id: int("id").autoincrement().primaryKey(),
  type: mysqlEnum("type", ["deposit", "withdrawal"]).notNull(),
  accountPhone: varchar("accountPhone", { length: 20 }).notNull(),
  phone: varchar("phone", { length: 20 }).notNull(),
  amount: int("amount").notNull(),
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DemoTransaction = typeof demoTransactions.$inferSelect;
export type InsertDemoTransaction = typeof demoTransactions.$inferInsert;

export const demoLedger = mysqlTable("demo_ledger", {
  id: int("id").autoincrement().primaryKey(),
  accountPhone: varchar("accountPhone", { length: 20 }).notNull(),
  kind: mysqlEnum("kind", ["deposit", "revenue", "referral", "checkin", "withdrawal", "purchase", "signup_bonus"]).notNull(),
  direction: mysqlEnum("direction", ["credit", "debit"]).notNull(),
  amount: int("amount").notNull(),
  transactionId: int("transactionId"),
  detail: varchar("detail", { length: 255 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type DemoLedgerEntry = typeof demoLedger.$inferSelect;
export type InsertDemoLedgerEntry = typeof demoLedger.$inferInsert;

export const demoPurchases = mysqlTable("demo_purchases", {
  id: int("id").autoincrement().primaryKey(),
  accountPhone: varchar("accountPhone", { length: 20 }).notNull(),
  productName: varchar("productName", { length: 100 }).notNull(),
  amount: int("amount").notNull(),
  status: mysqlEnum("status", ["completed", "cancelled"]).default("completed").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type DemoPurchase = typeof demoPurchases.$inferSelect;
export type InsertDemoPurchase = typeof demoPurchases.$inferInsert;