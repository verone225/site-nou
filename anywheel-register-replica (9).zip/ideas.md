# Direction de reproduction Anywheel

## Référence retenue

La page fournie à l’adresse `https://anywheesls.com/reg?code=d9s3p7` constitue la spécification visuelle de référence. La reproduction conserve le cadrage mobile étroit, la bannière cycliste, le bloc vert vif, le titre « REGISTER », les quatre champs blancs, le lien de connexion et le bouton « S'inscrire ». La version livrée reste un front-end autonome : aucune donnée saisie n’est transmise à un service tiers.

## Approches considérées

### Theme Name: Copie structurelle stricte
Very Brief Intro: Reprendre le rythme vertical, la palette verte et la hiérarchie de formulaire de la page de référence, tout en conservant une implémentation locale plus robuste.
Probability: 0.06

### Theme Name: Mobilité fraîche éditoriale
Very Brief Intro: Donner à l’écran une présence de campagne vélo contemporaine avec une image plus travaillée, une texture organique et une typographie nette, sans changer la logique du formulaire.
Probability: 0.04

### Theme Name: Portail utilitaire contrasté
Very Brief Intro: Transformer la page en portail de service plus dense, à contraste fort, avec une lecture prioritairement fonctionnelle et peu d’ornement.
Probability: 0.02

## Approche choisie : Copie structurelle stricte

### Design Movement
Référence directe à l’esthétique des écrans d’inscription de services de mobilité grand public : photographie lifestyle verticale, aplats de couleur de marque et formulaire compact.

### Core Principles
1. La silhouette mobile et le rythme vertical priment sur les conventions de landing page desktop.
2. Le vert vif sert de surface de confiance et d’énergie ; le blanc porte la lisibilité et l’action.
3. Chaque élément doit être immédiatement reconnaissable par rapport à la référence : bannière, titre, champs, lien puis CTA.
4. Les interactions restent rapides, sobres et locales, avec un retour clair après soumission.

### Color Philosophy
Le vert `#00c853` évoque l’énergie, le déplacement et la disponibilité du service. Le noir périphérique isole le dispositif mobile comme une capture d’app, tandis que les surfaces blanches rendent les contrôles lisibles même sur petit écran.

### Layout Paradigm
Une colonne portrait centrée, largeur fluide sur mobile et plafonnée à 320 px sur grand écran. La bannière occupe la partie supérieure ; le formulaire chevauche légèrement sa base pour reproduire la jonction de la référence.

### Signature Elements
Un cadre portrait flottant sur fond noir, une jonction arrondie entre photo et panneau vert, et des champs blancs avec icônes vertes à gauche.

### Interaction Philosophy
Les actions répondent immédiatement par une légère compression et une validation locale. Le lien de connexion agit comme une porte de sortie explicite ; la soumission affiche un état de démonstration et ne collecte aucune information.

### Animation
Entrée douce du cadre et du panneau par translation verticale de quelques pixels et opacité. Les champs réagissent au focus par une bordure verte et une ombre courte. Les animations restent sous 220 ms et sont désactivées pour les utilisateurs qui préfèrent réduire les mouvements.

### Typography System
Une police sans-serif arrondie et lisible pour le contenu, avec un titre en graisse 800 et un léger espacement des lettres. Les libellés et placeholders utilisent une taille compacte mais confortable ; le CTA est plus lourd et plus contrasté.

### Brand Essence
Un écran d’inscription Anywheel compact, énergique et rassurant pour les nouveaux utilisateurs d’un service de vélo urbain. Personality: direct, frais, accessible.

### Brand Voice
Les titres sont courts et opérationnels ; les CTA indiquent une action précise ; les microcopies restent simples et non promotionnelles.
Exemples : « REGISTER » et « Vos informations restent dans cette démo locale. »

### Wordmark & Logo
Le mot-symbole est rendu en lettres minuscules épaisses dans la bannière, complété par un symbole de roue-flèche abstrait utilisé comme accent et favicon.

### Signature Brand Color
Vert mobilité `#00c853`.
