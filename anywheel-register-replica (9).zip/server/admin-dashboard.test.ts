// @vitest-environment jsdom
import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { trpc } from "../client/src/lib/trpc";

const mocks = vi.hoisted(() => ({
  query: vi.fn(),
  mutate: vi.fn(),
  invalidate: vi.fn(),
  mutationOptions: null as null | { onSuccess?: () => void },
}));

vi.mock("../client/src/lib/trpc", () => ({
  trpc: {
    Provider: ({ children }: { children: React.ReactNode }) => React.createElement(React.Fragment, null, children),
    useUtils: () => ({ admin: { transactions: { invalidate: mocks.invalidate } } }),
    admin: {
      transactions: { useQuery: (input: unknown, options: unknown) => { mocks.query(input, options); return { data: [{ id: 1, type: "deposit", phone: "+2250787654321", amount: 3000, status: "pending", createdAt: new Date(), updatedAt: new Date() }], isLoading: false }; } },
      updateStatus: { useMutation: (options: { onSuccess?: () => void }) => { mocks.mutationOptions = options; return { mutate: mocks.mutate, isPending: false }; } },
    },
  },
}));

const { AdminDashboard } = await import("../client/src/pages/Home");

describe("AdminDashboard refresh", () => {
  beforeEach(() => { mocks.query.mockClear(); mocks.mutate.mockClear(); mocks.invalidate.mockClear(); mocks.mutationOptions = null; });

  it("configures polling and invalidates the list after a status mutation", () => {
    const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
    const adminTree = React.createElement(AdminDashboard, { onLogout: vi.fn() });
    const tree = React.createElement(QueryClientProvider, { client: queryClient }, React.createElement(trpc.Provider, null, adminTree));
    render(tree);
    expect(mocks.query).toHaveBeenCalledWith(undefined, expect.objectContaining({ refetchInterval: 3000 }));
    fireEvent.click(screen.getByRole("button", { name: "Valider" }));
    expect(mocks.mutate).toHaveBeenCalledWith({ id: 1, status: "approved" });
    mocks.mutationOptions?.onSuccess?.();
    expect(mocks.invalidate).toHaveBeenCalledTimes(1);
  });
});
