import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { createAdminSession } from "./adminSession";

const ctx = { req: { protocol: "https", headers: {} } as TrpcContext["req"], res: { cookie: () => undefined } as TrpcContext["res"], user: undefined } as TrpcContext;

describe("demo admin access", () => {
  it("authorizes the configured admin credentials", async () => {
    await expect(appRouter.createCaller(ctx).admin.verifyDemo({ phone: "+2250544894579", code: "010101" })).resolves.toEqual({ authorized: true });
  });

  it("rejects other credentials", async () => {
    await expect(appRouter.createCaller(ctx).admin.verifyDemo({ phone: "+2250700000000", code: "010101" })).resolves.toEqual({ authorized: false });
  });

  it("rejects transaction access without the signed admin cookie", async () => {
    await expect(appRouter.createCaller(ctx).admin.transactions()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("rejects a standard authenticated user from the admin flow", async () => {
    const standardCtx = { ...ctx, user: { id: 22, openId: "standard", name: "User", email: "user@example.com", loginMethod: "demo", role: "user", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() } } as TrpcContext;
    await expect(appRouter.createCaller(standardCtx).admin.transactions()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(appRouter.createCaller(standardCtx).admin.updateStatus({ id: 1, status: "approved" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("reports the admin session state", async () => {
    expect(await appRouter.createCaller(ctx).admin.me()).toEqual({ authorized: false });
    const session = createAdminSession("+2250544894579");
    const authenticatedCtx = { ...ctx, req: { protocol: "https", headers: { cookie: `magnesium_admin_session=${session.value}` } } as TrpcContext["req"] } as TrpcContext;
    expect(await appRouter.createCaller(authenticatedCtx).admin.me()).toEqual({ authorized: true });
  });

  it("accepts listing and status mutation with a signed admin cookie", async () => {
    const session = createAdminSession("+2250544894579");
    const authenticatedCtx = { ...ctx, req: { protocol: "https", headers: { cookie: `magnesium_admin_session=${session.value}` } } as TrpcContext["req"] } as TrpcContext;
    await expect(appRouter.createCaller(authenticatedCtx).admin.transactions()).resolves.toEqual(expect.any(Array));
    await expect(appRouter.createCaller(authenticatedCtx).admin.updateStatus({ id: 1, status: "approved" })).resolves.toBeUndefined();
  });
});
