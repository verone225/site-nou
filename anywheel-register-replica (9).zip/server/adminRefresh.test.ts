import { describe, expect, it } from "vitest";
import { ADMIN_REFETCH_INTERVAL_MS, shouldRefreshAfterAdminMutation } from "../client/src/lib/adminRefresh";

describe("admin refresh behavior", () => {
  it("polls every three seconds and refreshes after a mutation", () => {
    expect(ADMIN_REFETCH_INTERVAL_MS).toBe(3000);
    expect(shouldRefreshAfterAdminMutation()).toBe(true);
  });
});
