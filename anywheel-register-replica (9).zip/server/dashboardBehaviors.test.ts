import { describe, expect, it } from "vitest";
import { announcementStartsOpen, dismissAnnouncement, getActionMessage } from "../client/src/lib/dashboardBehaviors";

describe("dashboard behaviors", () => {
  it("starts with the announcement open", () => {
    expect(announcementStartsOpen).toBe(true);
  });

  it("closes the announcement after the access action", () => {
    expect(announcementStartsOpen).toBe(true);
    expect(dismissAnnouncement()).toBe(false);
  });

  it("provides a useful message for every main action", () => {
    expect(getActionMessage("Recharge")).toMatch(/dépôt/);
    expect(getActionMessage("Retrait")).toMatch(/1 500 FCFA/);
    expect(getActionMessage("Retrait")).toMatch(/20 %/);
    expect(getActionMessage("Aide")).toMatch(/aide/);
    expect(getActionMessage("Pointage")).toMatch(/présence quotidienne/);
    expect(getActionMessage("unknown")).toMatch(/espace personnel/);
  });
});
