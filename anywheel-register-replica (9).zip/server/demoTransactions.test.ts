import { afterEach, describe, expect, it } from "vitest";
import { addDemoTransaction, getDemoTransactions, maskWavePhone, updateDemoTransactionStatus } from "../client/src/lib/demoTransactions";

function storage() {
  const data = new Map<string, string>();
  return { getItem: (key: string) => data.get(key) ?? null, setItem: (key: string, value: string) => data.set(key, value) } as Storage;
}

afterEach(() => { delete (globalThis as { localStorage?: Storage }).localStorage; });

describe("admin demo transactions", () => {
  it("stores a request and lets the admin update its status", () => {
    (globalThis as { localStorage: Storage }).localStorage = storage();
    const item = addDemoTransaction({ type: "withdrawal", phone: "+2250700000000", amount: 2750 });
    expect(getDemoTransactions()[0]?.status).toBe("pending");
    expect(maskWavePhone(item.phone)).toContain("****");
    expect(updateDemoTransactionStatus(item.id, "approved")[0]?.status).toBe("approved");
  });
});
