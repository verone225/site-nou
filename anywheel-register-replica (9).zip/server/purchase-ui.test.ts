// @vitest-environment jsdom
import React from "react";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

afterEach(() => {
  document.body.innerHTML = "";
  localStorage.clear();
  invalidate.mockClear();
  purchaseMode = "success";
  portfolioData.balanceCfa = 4500;
});

const invalidate = vi.fn(() => {
  portfolioData.balanceCfa = 1500;
});
let purchaseMode: "success" | "error" = "success";
const portfolioData = { balanceCfa: 4500, cumulativeRevenueCfa: 1500, referralRevenueCfa: 0, hasPurchased: false, ledger: [] as unknown[] };

vi.mock("../client/src/_core/hooks/useAuth", () => ({ useAuth: () => ({ user: { name: "Compte test" }, logout: vi.fn() }) }));
vi.mock("../client/src/lib/trpc", () => ({
  trpc: {
    useUtils: () => ({ demoAccount: { portfolio: { invalidate } } }),
    demoAccount: {
      portfolio: { useQuery: () => ({ data: portfolioData, isLoading: false }) },
      purchaseProduct: { useMutation: (options: any) => ({ mutate: () => purchaseMode === "success" ? void options.onSuccess?.() : void options.onError?.(new Error("Solde insuffisant pour acheter ce produit.")), isPending: false }) },
    },
  },
}));

import { Dashboard } from "../client/src/pages/Home";

describe("Product purchase balance UI", () => {
  it("refreshes the visible balance after a successful product purchase", async () => {
    const view = render(React.createElement(Dashboard, { accountLabel: "2250700000000", onLocalLogout: vi.fn() }));
    expect(screen.getByText(/FCFA 4.*500/)).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "Produit" }));
    fireEvent.click(screen.getAllByRole("button", { name: /Acheter/i })[0]);
    await waitFor(() => expect(invalidate).toHaveBeenCalledWith({ phone: "+2250700000000" }));
    view.rerender(React.createElement(Dashboard, { accountLabel: "2250700000000", onLocalLogout: vi.fn() }));
    fireEvent.click(screen.getByRole("button", { name: "Accueil" }));
    expect(screen.getByText("Solde du compte").closest("article")?.textContent).toMatch(/FCFA 1.*500/);
  });

  it("shows a clear insufficient-balance message after clicking Acheter", async () => {
    purchaseMode = "error";
    render(React.createElement(Dashboard, { accountLabel: "2250700000000", onLocalLogout: vi.fn() }));
    fireEvent.click(screen.getByRole("button", { name: "Produit" }));
    fireEvent.click(screen.getAllByRole("button", { name: /Acheter/i })[0]);
    await waitFor(() => expect(screen.getByRole("status").textContent).toMatch(/solde insuffisant/i));
  });
});
