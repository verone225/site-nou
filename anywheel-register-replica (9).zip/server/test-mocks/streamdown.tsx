import React from "react";

export function Streamdown({ children }: { children: string }) {
  return <div>{children}</div>;
}
