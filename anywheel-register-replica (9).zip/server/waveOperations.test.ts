import { describe, expect, it } from "vitest";
import { isValidWavePhone, isValidWaveWithdrawalAmount, validateWaveWithdrawal, wavePackAmounts } from "../client/src/lib/waveOperations";

describe("Wave operations", () => {
  it("accepts Ivorian Wave phone numbers only", () => {
    expect(isValidWavePhone("+225 07 00 00 00 00")).toBe(true);
    expect(isValidWavePhone("+33 06 00 00 00 00")).toBe(false);
  });

  it("exposes the three deposit pack amounts", () => {
    expect(wavePackAmounts).toEqual([3000, 10000, 25000]);
  });

  it("accepts the supported withdrawal amounts", () => {
    expect(isValidWaveWithdrawalAmount(1500)).toBe(true);
    expect(isValidWaveWithdrawalAmount(999)).toBe(false);
  });

  it("validates a manually entered withdrawal", () => {
    expect(validateWaveWithdrawal("+33 06 00 00 00 00", 1500)).toMatch(/numéro Wave/);
    expect(validateWaveWithdrawal("+225 07 00 00 00 00", 0)).toMatch(/supérieur à 0/);
    expect(validateWaveWithdrawal("+225 07 00 00 00 00", 50)).toMatch(/1 500 FCFA/);
    expect(validateWaveWithdrawal("+225 07 00 00 00 00", 2750)).toBeNull();
  });
});
